package com.project.project.hospitalfinder.data;

public class Appointments {

    public static String hospitalName = "hospitalName";

    public static String date = "date";

    public static String time = "time";

    public static String username = "username";

    public static String specialist = "specialist";

}
