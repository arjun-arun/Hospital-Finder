package com.project.project.acommon;

import android.app.Application;

import com.parse.Parse;

public class MyApplication extends Application {
    @Override
    public void onCreate() {
        super.onCreate();


        // college marks
        /*Parse.initialize(new Parse.Configuration.Builder(this)
                .applicationId("TyGNVjpKbqs6w0Kv03LzA0DfhvqctQFFmTybzxU1")
                // if defined
                .clientKey("EGWgJASzgm00aPs0cHuwgj2DbaicQDzw22NBPDp3")
                .server("https://parseapi.back4app.com")
                .build()
        );*/


        // TravelGuide
        /*Parse.initialize(new Parse.Configuration.Builder(this)
                .applicationId("Krewh6WYWI79PYjKogPmFt9q68UgFFJNJT0FUysc")
                // if defined
                .clientKey("OCrEFIihbayVtq1quJSzi2PCASOytkG53yZEPTMz")
                .server("https://parseapi.back4app.com")
                .build()
        );*/


        // TripInfo
        /*Parse.initialize(new Parse.Configuration.Builder(this)
                .applicationId("Za7Dul9nVONsMu1LPZUTttWMXuynT12KMMQXvgIT")
                // if defined
                .clientKey("wrX7g2qNsNJGW0s6T8sV044lsQseeuO3vTc454qI")
                .server("https://parseapi.back4app.com")
                .build()
        );*/


        // Salon
/*
        Parse.initialize(new Parse.Configuration.Builder(this)
                .applicationId("sMWoJ2KA4eWIC1ieYrfjJ4whMdxvlrT2DYfNWCyu")
                // if defined
                .clientKey("XeUxKV5TLe3fquB1cRT8u4MF4DtclXQbiU1DqUuD")
                .server("https://parseapi.back4app.com")
                .build()
        );
*/


        // Gift store portal
        /*Parse.initialize(new Parse.Configuration.Builder(this)
                .applicationId("a0xJ2Oc0CPn7J8sbbdBqyBz6lJrGRhfPPxp2jnEQ")
                // if defined
                .clientKey("ks5JIHW0r01uuiqIyZ4QVjlMpKc2kifqcyRf58HL")
                .server("https://parseapi.back4app.com")
                .build()
        );*/

        // College selector
/*
        Parse.initialize(new Parse.Configuration.Builder(this)
                .applicationId("Dlxz7MkDfYoWto6y3XKSbQY1B6RGNl899D9aHLSa")
                // if defined
                .clientKey("LeFWw5c3RIICbggHNBvmrL6BhvPVlsjkq1QLJPeo")
                .server("https://parseapi.back4app.com")
                .build()
        );
*/


        // bangalore guide
        /*Parse.initialize(new Parse.Configuration.Builder(this)
                .applicationId("C3P2faVNiYsoNgE0YZxT1uF0ZxfeWrrOs4OXOgKz")
                // if defined
                .clientKey("lP6n8vT1KGZ8wtE1XBwu31Jkte9PsppwPWjJsq61")
                .server("https://parseapi.back4app.com")
                .build()
        );*/

        // reminder
        /*Parse.initialize(new Parse.Configuration.Builder(this)
                .applicationId("Izlr3OsAynBmRRyXyzLPgPi8rsGwxHI2ogcQ3ac6")
                // if defined
                .clientKey("u78OWgyheFlgkvfedigPssCf1tnWyjmP7Xn5NObf")
                .server("https://parseapi.back4app.com")
                .build()
        );*/

        // Food catering
        /*Parse.initialize(new Parse.Configuration.Builder(this)
                .applicationId("EA8z1Jtm4VOUWb6xANjRvDwEBq3ZDH3EaFF3HyGf")
                // if defined
                .clientKey("BLFPstMytk0voUJUkMDZkdjB4GHXpljg9rEbPRqC")
                .server("https://parseapi.back4app.com")
                .build()
        );*/


        // Fees payment
        /*Parse.initialize(new Parse.Configuration.Builder(this)
                .applicationId("sNtjsyLvFOu0r8vpX2O6eVvMqERtH2CGTCdiW5YE")
                // if defined
                .clientKey("8tuTdM19jdL6yexzBDAqD9sHcEgtWEzi3dJNaCCH")
                .server("https://parseapi.back4app.com")
                .build()
        );*/

        // Kisanmitra
       /* Parse.initialize(new Parse.Configuration.Builder(this)
                .applicationId("lMY1wseVoCMSiZ4PKoF8Gq2Pw5NUjMML8nztCysl")
                // if defined
                .clientKey("3HI8oD2dGNv95jrVOYAHff78V09Fo5cSmXQABE22")
                .server("https://parseapi.back4app.com")
                .build()
        );*/

        // TPROBS
        /*Parse.initialize(new Parse.Configuration.Builder(this)
                .applicationId("CxtmpTlUxJlztBfb9TRlW0bRV3ODgMhzZP1WBuKj")
                .clientKey("R5HVYfN9ZD3z0PViF7KfLMSV5nIvfeogFcyZwjez")
                .server("https://parseapi.back4app.com")
                .build()
        );*/

        // Ambulance
//        Parse.initialize(new Parse.Configuration.Builder(this)
//                .applicationId("5SJdS4LbE6hWydzSppc3BnkAtdE6ReZQEgWFwBKO")
//                // if defined
//                .clientKey("rFCanqJXIqaUqsk760DRLXPzHCManSgOeX8Tpjtq")
//                .server("https://parseapi.back4app.com")
//                .build()
//        );

        // KisanPrediction
       /* Parse.initialize(new Parse.Configuration.Builder(this)
                .applicationId("cfAesPGgtQQfuuNGMd95ypST3g3t0ReHfCNiLbdr")
                // if defined
                .clientKey("rHQBsPeFXWS10nSAG0hfYHruceUSaNAfIf81uYbB")
                .server("https://parseapi.back4app.com")
                .build()
        );*/


        // campus recruitment
        /*Parse.initialize(new Parse.Configuration.Builder(this)
                .applicationId("Y5TDLIOhRiHdleUq8ylD8tAbLj2Mul0MzHeNOQUe")
                // if defined
                .clientKey("NURV5b7H3gqdMOpYCwg27VBHp5e3NHW92vdlwfZT")
                .server("https://parseapi.back4app.com")
                .build()
        );*/


        // invetory
        /*Parse.initialize(new Parse.Configuration.Builder(this)
                .applicationId("lIDBx80J5Tptp0AC7w97ZhVlfJiQwg3X9Nlu8CRe")
                // if defined
                .clientKey("gu1xWp1ACKR0rQ3BU8HSBMtqrFGBef9Kx7l18ssT")
                .server("https://parseapi.back4app.com")
                .build()
        );*/

        // health chatbot
        /*Parse.initialize(new Parse.Configuration.Builder(this)
                .applicationId("wPWb02w6tcXn29fWxDLwyA8NrAuvnL1KDWxp1GDN")
                // if defined
                .clientKey("PHzk8vuPczQNo6rYEMoQKOtzw1OU6BgNWQKhyvMg")
                .server("https://parseapi.back4app.com")
                .build()
        );*/


        // Blood bank
        /*Parse.initialize(new Parse.Configuration.Builder(this)
                .applicationId("cvD8ZeE4IMCyymLRiUaYk3xmgRuRJhz1vtGLDsUc")
                // if defined
                .clientKey("hYiMJkm3aZyLJD99NTR5Fea3HVJMuzIcuKl300ec")
                .server("https://parseapi.back4app.com")
                .build()
        );*/


        //Video routing
        /*Parse.initialize(new Parse.Configuration.Builder(this)
                .applicationId("zVb8NK26vzHg0zi6VC3aNHU9WRqUj0o6dNeh1Nwj")
                // if defined
                .clientKey("3o0IX71bXnHqXN6elnNNGD43A78iyAPD0IWjpokX")
                .server("https://parseapi.back4app.com")
                .build()
        );*/

        // RoadAssistance
        /*Parse.initialize(new Parse.Configuration.Builder(this)
                .applicationId("Ef0EBqtSVr1wkQpA6EIs5bdpbnxPUgpt3jEA3BdN")
                .clientKey("Cl3rfL4PgVRtSg43dj8bUNQr9hqc2srYKYPgw6t7")
                .server("https://parseapi.back4app.com")
                .build()
        );*/

        // Construction
        /*Parse.initialize(new Parse.Configuration.Builder(this)
                .applicationId("Ad9hGtSZwlaPMiTTE2HC4P0zmfs32nVxXyEfeiAB")
                .clientKey("StDRgqA5nfBUdfc5KOTLTasSBel0RwmueATprWR8")
                .server("https://parseapi.back4app.com")
                .build()
        );*/

        // Alumni
        /*Parse.initialize(new Parse.Configuration.Builder(this)
                .applicationId("aE8thjoJAYiERMRdERmf8hmYUzqi03ajRG6XI7ue")
                .clientKey("XuI2L2tnfJUVdOSi1Kx5u81mLxfmLh0vmCAagAEG")
                .server("https://parseapi.back4app.com")
                .build()
        );*/


        // signature
        /*Parse.initialize(new Parse.Configuration.Builder(this)
                .applicationId("CPI8SQfAVOh7ZiCNowaH5pfH3RgsUZlYfvg9GYPZ")
                // if defined
                .clientKey("vQcTU6Iuf1jyf2GelCtiPuAUBOFczy0yrPrtGQK7")
                .server("https://parseapi.back4app.com")
                .build()
        );*/

        // Voter
        /*Parse.initialize(new Parse.Configuration.Builder(this)
                .applicationId("QpcJIshQymxIPXk4g796NDX6TQ4VUE5IoEhmtL9b")
                // if defined
                .clientKey("IYuzxEIzeXWXkZzSObKfKWs5sIURxlN23xdiGwtR")
                .server("https://parseapi.back4app.com")
                .build()
        );*/

        // Civicawareness
        /*Parse.initialize(new Parse.Configuration.Builder(this)
                .applicationId("jLHrOARDahrvXfqpOjofRMVT7l2KNXIGSyM034S7")
                // if defined
                .clientKey("XCKDNeehcQLuZu4MaZRS0AXzhjSci9DuhqdqxNAz")
                .server("https://parseapi.back4app.com")
                .build()
        );*/

        // MedicateBMI
        /*Parse.initialize(new Parse.Configuration.Builder(this)
                .applicationId("ocNdJuPdnT9n2ONf4j0wKWipWD0WwAjjlJYotdzj")
                // if defined
                .clientKey("vU91Vyv1eijaIrxDUEO0LYtPUYc1KchGTsGoRoTC")
                .server("https://parseapi.back4app.com")
                .build()
        );*/

        // Driverapp
        /*Parse.initialize(new Parse.Configuration.Builder(this)
                .applicationId("6WjwAdxTRq7a5OmDxX05GM7BfmRqRP5cgV2Gk6Yr")
                // if defined
                .clientKey("1xrf6GVtYfBLIyoAV0igGRXMiSJpUBmQSj2N8dSP")
                .server("https://parseapi.back4app.com")
                .build()
        );*/

        // Gym
        /*Parse.initialize(new Parse.Configuration.Builder(this)
                .applicationId("DY9pTAZ6Rg5odGz51q1M0m5MvID4AGlCnerU1NMx")
                // if defined
                .clientKey("idghH2TOS14zoxouDAppRipBwGLjFt7ZsbLHkVHh")
                .server("https://parseapi.back4app.com")
                .build()
        );*/

        // optraev
        /*Parse.initialize(new Parse.Configuration.Builder(this)
                .applicationId("lAzPi7Bx4EXMOB4DzVgVYWDQvsVXb35Af06ayj7d")
                // if defined
                .clientKey("AW8mOQHgITWRxI3u9h7V9xNOLtCj3DU0x0G2TddR")
                .server("https://parseapi.back4app.com")
                .build()
        );*/

        //chat
        /*Parse.initialize(new Parse.Configuration.Builder(this)
                .applicationId("96UqRSihDdJiKhsUDU5dVAkPlQOpSoiqdLna15Wc")
                // if defined
                .clientKey("rfAjM1W5P4Rrjd0NLMt1yMnBMfDPJ5pmaokdD0W2")
                .server("https://parseapi.back4app.com")
                .build()
        );*/

        //eLibrary
        /*Parse.initialize(new Parse.Configuration.Builder(this)
                .applicationId("FursBA6JGSOgzaj21xdZPmicPPReBjWrNKc6S73J")
                // if defined
                .clientKey("cHK4m1dW4Cfb9r78QjqleBcUbkUQYCL9Zkztcukm")
                .server("https://parseapi.back4app.com")
                .build()
        );*/


        // Medibot
        /*Parse.initialize(new Parse.Configuration.Builder(this)
                .applicationId("V7JCn1yZHpG84pQWyVjxSY3vmOKP4mapTBFqscKp")
                // if defined
                .clientKey("FUxXiIi31ZHNAKQcMrIZjaJ3sMVnIXnNnUkq79el")
                .server("https://parseapi.back4app.com")
                .build()
        );*/
        
        // Digital library
       /* Parse.initialize(new Parse.Configuration.Builder(this)
                .applicationId("ZIvZkiYVEDPn4xt7ZPGzLWnUJdiEai05tTqQSRv0")
                .clientKey("Ct8ssbY3ShIhJnHJsv2JKqWppg8h0q2z3HNX6z5x")
                .server("https://parseapi.back4app.com")
                .build()
        );*/

        // Drone
        /*Parse.initialize(new Parse.Configuration.Builder(this)
                .applicationId("4SOwmNRKjvo5BewfLy3GyfF9utAACB53lm2P8967")
                .clientKey("BozbxOnysbbPKC6oKxS8tlOykxjqsrkawcLQYimg")
                .server("https://parseapi.back4app.com")
                .build()
        );*/

        // Food Donor
        /*Parse.initialize(new Parse.Configuration.Builder(this)
                .applicationId("GmfSOHQtwNONqrRwSsHOCHxEfUU5PyaUewLPbyP0")
                .clientKey("6P6K1dITnFjtq4qoXDvTQUFuWyA8oumkL6IUz6RX")
                .server("https://parseapi.back4app.com")
                .build()
        );*/

//         Hostel management
        /*Parse.initialize(new Parse.Configuration.Builder(this)
                .applicationId("5FyzZzTs9wkhDEqQPiyqqVwmcoSroewKG69lmqy7")
                .clientKey("mIpRPQKYnYL3ekLdlAD5VIzNOvk385ujZp6SevSD")
                .server("https://parseapi.back4app.com")
                .build()
        );*/

        //  Coliving
        /*Parse.initialize(new Parse.Configuration.Builder(this)
                .applicationId("FJhKFsa8QsMcIFYpdZzJxelPMnpji25I1WWKdMb8")
                .clientKey("kylAoKPEApksZUwdUC1ogCrW6S1qIGgFi4Z4yYIs")
                .server("https://parseapi.back4app.com")
                .build()
        );*/

        //  Hospital finder
        Parse.initialize(new Parse.Configuration.Builder(this)
                .applicationId("5LIfAtrI5xJ9Ecdu7u6Zv0YHVFZAl4MeBRKsGSeI")
                .clientKey("MxFMej5eDvR5kVDmowPgHhUTLnwGRGvO84vIfRbd")
                .server("https://parseapi.back4app.com")
                .build()
        );
    }
}
